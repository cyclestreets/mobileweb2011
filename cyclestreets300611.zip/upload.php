<?php
header('content-type: application/json; charset=utf-8');

# TODO: logic for saving username and password securely.
#session_start();
#$_SESSION['username']='1';

// Upload a photo. Collect POST variables and send on to CycleStreets.
// Use instead of direct POST because of cross-domain 
// Ajax POST restrictions.
// Requires cURL to be installed.

if ($_FILES["file"]["error"] > 0) {
    echo "Error: " . $_FILES["mediaupload"]["error"] . "<br />";
	// TODO: validate the file?
	// JPG only and max size 50MB?
	// TODO: make a nice error page?
} else {
	$fields = array(
		'mediaupload'=>'@' . $_FILES['mediaupload']['tmp_name'],
	    'username'=>urlencode($_POST["username"]),
	    'password'=>urlencode($_POST["password"]),
	    'latitude'=>urlencode($_POST["latitude"]),
	    'longitude'=>urlencode($_POST["longitude"]),
	    'datetime'=>urlencode($_POST["datetime"]),
	    'category'=>urlencode($_POST["category"]),
	    'metacategory'=>urlencode($_POST["metacategory"]),
	    'caption'=>urlencode($_POST["description"])
	);
	$fields_string = http_build_query($fields);
	$url = 'https://www.cyclestreets.net/api/addphoto.json?key=68f786d958d1dbfb';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST,count($fields));
    curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	// Output the response, whatever it is. 
	$response = curl_exec ($ch);
	
    // TODO: understand why we're getting this?
	//{"request":{"datetime":"1308661931"},"error":{"code":"unknown","message":"The photo was received successfully, but an error occurred while processing it."},"result":{}} 

	// TODO: obtain photo ID from response, once it's working!
	echo $response; 
	curl_close ($ch);
	$photo_id = '344';
	$photo_url = 'photo.html?p=' . $photo_id; 
	//header("Location: $photo_url");
}

?>