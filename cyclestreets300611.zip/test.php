<?php

	$fields = array(
		'mediaupload'=>'@' . $_FILES['mediaupload']['tmp_name'],
	    'username'=>urlencode($_POST["username"]),
	    'password'=>urlencode($_POST["password"]),
	    'latitude'=>urlencode($_POST["latitude"]),
	    'longitude'=>urlencode($_POST["longitude"]),
	    'datetime'=>urlencode($_POST["datetime"]),
	    'category'=>urlencode($_POST["category"]),
	    'metacategory'=>urlencode($_POST["metacategory"]),
	    'caption'=>urlencode($_POST["description"])
	);
	$fields_string = http_build_query($fields);
	echo $fields_string;
?>