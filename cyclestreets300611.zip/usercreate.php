<?php 
// Register user: collect POST variables and send on to CycleStreets.
// Requires cURL to be installed.
header('content-type: application/json; charset=utf-8');
$fields = array(
    'username'=>urlencode($_POST["username"]),
    'password'=>urlencode($_POST["password"]),
    'name'=>urlencode($_POST["name"]),
    'email'=>($_POST["email"])
);
$fields_string = http_build_query($fields);
$url = 'https://www.cyclestreets.net/api/usercreate.json?key=68f786d958d1dbfb';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POST,count($fields));
curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec ($ch);
echo $response; 
curl_close ($ch);
?>
